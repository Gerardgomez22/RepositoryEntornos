#include <iostream>
using namespace std;
int a, b, suma, resta, multiplica, divide;
void pedirDatos() {
	cout << "Ingrese el primer numero: ";
	cin >> a;
	cout << "Ingrese el segundo numero: ";
	cin >> b;
}
void sumar() {
	suma = a + b;
}
void restar() {
	resta = a - b;
}
void multiplicar() {
	multiplica = a * b;
}
void dividir() {
	divide = a / b;
}
void mostrarResultado() {
	cout << "La suma es: " << suma << endl;
	cout << "La resta es: " << resta << endl;
	cout << "La multiplicacion es: " << multiplica << endl;
	cout << "La division es: " << divide << endl;
}
int main()
{
	pedirDatos();
	sumar();
	restar();
	multiplicar();
	dividir();
	mostrarResultado();
	system("pause");
	return 0;
}
